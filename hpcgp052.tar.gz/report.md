omp.h
We use #pragma clause with different arguments to parallelize our code. To be more specific, we use schedule with input argument nonmonotonic:dynamic. We also use the functions omp_set_num_threads to set the number of threads and omp_get_thread_num to parse the right thread number for the given thread.

time.h
This library is used to benchmark our program with the use of timespec_get.

We use functions from the stdlib.h and stdio.h to parse arguments and also read from file. More specifically we use fread to read strings from the file with an appropriate length, in our case the length of a cell. We use fseek to avoid reading in '\n' and also make sure that the FILE * is pointing to the right cell in the file. In the beginning we also use fgetc to read a char and count the number of times '\n' is written in the file.

math.h
We use sqrt from this library. It could be argued that a change to sqrtf would fasten up the program. Instead of using the round function given by this library we simply do our own with casting to an int after adding 0.5 to the value.

We define a struct called coordinate which contains three doubles. This struct then allocates 24 bytes of memory since one double is 8 bytes and a struct is allocating some integer multiple of 8 bytes.



--------------------------------------------------------

The program initializes by decoding the arguments given from the terminal. The only argument here is -tXX where XX is the number of threads the program should use. First the program runs through the file "cells" and check how many lines it contains i.e. the number of cells.

The second step is to allocate an array, called numb_distances_times, that will contain all the frequencies of the possible distances. Since the assumptions in the assignment limit the possible coordinates, the number of possible distances with only 2 decimals is bounded. Since every coordinate lies between -10 and 10 in every dimension we can see that the maximal distance between two points is sqrt(20^2+20^2+20^2) which is roughly equal to 34.65. Also we have the smallest distance to be 00.00 and thus we need an array of size 3466. We store the frequencies as ints in this array and we also make this array to be 3466 * (number of threads +1) large. This way we can let the first 3466 numbers stay 0 and still let every thread compute and store its respectively frequencies in a corresponding index of the array.

Next step is to actually initialize the parallelization which calculates the distances between all the points. This is done by #pragma omp parallel for, which start the given number of threads in the first "for"-loop that comes in its way. We also use the schedule clause with the input argument "nonmonotonic:dynamic" which splits the for-loop accordingly such that every thread will work till the end. More exactly it will assign an appropriate index to every thread in every loop such that the threads optimally will work on blocks that require more iterations in the beginning and finish with the blocks that require fewer iterations.

Once all the distances have been calculated and stored in numb_distances_times we will sum the array for every index = 0...3465 such that the first 3466 elements in the array will contain the correct frequencies of all distances between the cells in the file. The last step is simply to print out the corresponding frequency to the right index in the array and decode the index to print the "right" distance, i.e. distance 1738 in the array will then actually be printed as 17.38.


------------------------------------------------------

Distance_block is the function which the threads will start once they have received their index in the for-loop. This function receives the appropriate 'start' index, the argument int m which states how many cells is left in the file after cell 'start' and also the thread id.

First the function will read the first block from the file that the 'start' index corresponds to; this is done by our function 'fileReadingMult'. The size of the block will be block_size which is fixed as a global variable. Once this is read, it will simply convert every cell from a char * to a coordinate with the function 'converter'. This function converts the string to longs and parse them to doubles with the right sign.

Once we have the cells as coordinates we are ready to compute the distances between the cells in the first block. This is done by our function 'dist' which besides calculating the actual distance it also increments the corresponding frequency in 'numb_distances_times' array. To avoid calculating the distance between the same cells twice, we always calculate distances from a given cell to consecutive cells and never to a cell earlier in the file.

The next step is to start calculating the distance from this block of cells to the rest of the consecutive cells in the file. This is done by reading in another consecutive block from the file and converting these corresponding coordinates. This means we have two blocks in the memory which we then let the thread calculate the distances between every cell in the first block with every cell in the second block, once again with the use of 'dist'. Once we have done this we will free the memory of the second block and simply start with the same procedure with the next block.

This will be repeated until every consecutive cell that is left in the file has been computed. Note that this number will be given by 'm' as an argument to the function. In the end it will also free the memory of the first allocated block.

With regard to the memory allocation limit of 1GB we will give details of the programs memory usage. The total memory usage is independent of the amount of cells in the file. Every thread will allocate memory for their computations in the following manner:
24 bytes for the coordinate of every cell, 23 bytes of the chars for every cell and 8 bytes for the char* of every cell. At a given time we will allocate no more than 2 blocks of cells per thread and hence the memory allocation will be
numb_threads * 2 * block_size * (24+23+8).

The Block_size was optimized with benchmarking and we found that the size of 1000 was the best. Thus by setting block_size = 1000 and numb_threads = 20 we will allocate a bit more than 2MB of memory.

As stated above, parallelization of the computation of the distances is done by the OpenMP for construct, including the schedule clause with the option "nonmonotonic:dynamic". The choice of this option comes from the fact that blocks with small indices contains marginally more computations than blocks with large indices. However, there are scenarios where the option 'static,1' could perhaps perform just as well.  In case there are few threads, then if they work on neighbouring block the difference in number of computations won't be as large. Hence they could finish approximately at the same time. However, since the assignment of work items is done in cyclic order, the total number of computations for the first thread would be a lot larger than for the last thread, causing an imbalance between the threads and they will be starved. Thus, it is probable that static will perform worse even for few threads.

To test the above argument, benchmarking was done. The program was run 500 times with each option, 'nonmonotonic:dynamic' and 'static,1', respectively, on a file containing 10^5 cells. This was done for 5, 10 and 20 threads respectively. These runs resulted in the average runtimes shown in the table below.

| num_Threads | dynamic:nonmonotonic | static,1 |
|:----:|----:|----:|
| 5 | 6.78123 | 7.32264 |
| 10 | 3.46793 | 3.99156 |
| 20 | 1.81265 | 2.13892 |

The option 'static,1' performs worse in all cases, even in the case of only five threads. We see that it becomes slower with the addition of more threads, which is reasonable as then the difference in indices for which the threads work on will increase.
