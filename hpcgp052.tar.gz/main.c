#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <omp.h>

#define NANO 0.000000001
#define MILLI 0.001
#define MAX_DIST 3466
#define filename  "cells"


typedef struct{
  double x;
  double y;
  double z;
} coord;

/* Global variables
numb_distances_times: counter of frequencies of distances
block_size: size of the block that is fetched from the file
*/
int * numb_distances_times;
int block_size;


// Converts a cell from chars to coordinates
coord converter(char * numb1){
  coord a;
  double x1 = strtol(numb1+1,NULL,10);
  double x2 = strtol(numb1+4,NULL,10);
  double y1 = strtol(numb1+9,NULL,10);
  double y2 = strtol(numb1+12,NULL,10);
  double z1 = strtol(numb1+17,NULL,10);
  double z2 = strtol(numb1+20,NULL,10);

  a.x = (x1+x2*MILLI);
  if (numb1[0] == '-'){
    a.x = -1.0*a.x;
  }

  a.y = (y1+y2*MILLI);
  if (numb1[8] == '-'){
    a.y = -1.0*a.y;
  }

  a.z = (z1+z2*MILLI);
  if (numb1[16] == '-'){
    a.z = -1.0*a.z;
  }

  return a;
}

/* Computes the distance between two points and increments the counter
of that distance
*/
void dist(coord a, coord b,int N){
  double x = a.x-b.x;
  double y = a.y-b.y;
  double z = a.z-b.z;
  double distance = sqrt(x*x+y*y+z*z);
  distance = (distance * 100.0+0.5);
  int inc = (int) (distance);
  numb_distances_times[inc+N*MAX_DIST] = numb_distances_times[inc+N*MAX_DIST]+1;
}

// Reads one block from the file starting from cell n to cell n+m.
char ** fileReadingMult(int n,int m){
  int N = 23;
  FILE * fp;
  fp = fopen(filename,"r");
  fseek(fp,(n)*(N+1),SEEK_SET);
  char ** as = malloc(sizeof(char*)*m);
  for (size_t ix = 0; ix < m; ix++) {
    as[ix] = malloc(sizeof(char)*N);
    fread(as[ix],sizeof(char),N,(fp));
    fseek(fp,1,SEEK_CUR);
  }
  fclose(fp);
  return as;
}

/*
Receives block index and thread index. First calculates within the given block
and then computes the distances to the other blocks iteratively.
*/
void distance_block(int start,int m,int thread_n){
  char ** points  = fileReadingMult(start,block_size);
  char ** newPoints;
  coord c[block_size];
  coord d[block_size];

  for (size_t ix = 0; ix < block_size; ix++) {
    c[ix] = converter(points[ix]);
  }

  for (size_t ix = 0; ix < block_size; ix++) {
    for (size_t jx = ix+1; jx < block_size; jx++) {
      dist(c[ix],c[jx],thread_n);
    }
  }

  for (size_t ix = start+block_size; ix < m+start; ix+=block_size) {
    newPoints = fileReadingMult(ix,block_size);
    for (size_t jx = 0; jx < block_size; jx++) {
      d[jx] = converter(newPoints[jx]);
      free(newPoints[jx]);
      for (size_t kx = 0; kx < block_size; kx++) {
        dist(c[kx],d[jx],thread_n);
      }
    }
    free(newPoints);
  }
  free(points);
}



int main(int argc, char * argv[]){
  block_size = 1000;

// Parsing arguments
  if (argc != 2) {
    printf("Wrong number of arguments\n");
    return -1;
  }

  int numb_threads;
  if (argv[1][0] == '-' && argv[1][1] == 't'){
    numb_threads = strtol(argv[1]+2,NULL,10);
  }
  else {
    printf("Wrong input\n");
    return -1;
  }

// Counts the number of cells in the file "cells".
  int numb_points = 0;
  int ch;
  FILE * fp;
  fp = fopen(filename,"r");
  while(!feof(fp)){
    ch = fgetc(fp);
    if(ch == '\n'){
      numb_points++;
    }
  }
  fclose(fp);

  /*
  Creating an array with frequencies of distances. Each thread will be indexed
  to count its distances on an appropriate index in this array.
  */
  numb_distances_times = malloc(sizeof(int)*MAX_DIST*(numb_threads+1));
  for (size_t ix = 0; ix < MAX_DIST*(numb_threads+1); ix++) {
    numb_distances_times[ix] = 0;
  }

  // We let the dynamic clause assign appropriate blocks for the different threads
  omp_set_num_threads(numb_threads);
  size_t ix = 0;
  #pragma omp parallel for schedule(nonmonotonic:dynamic) shared(numb_distances_times)
  for (ix = 0; ix < numb_points; ix+=block_size) {
    distance_block(ix,numb_points-ix,(omp_get_thread_num()+1));
  }

  // Hardcoded "reduction" adapted to this implementation
  for (size_t ix = 0; ix < MAX_DIST; ix++) {
    for (size_t jx = 0; jx < numb_threads+1; jx++) {
      numb_distances_times[ix] += numb_distances_times[ix+jx*MAX_DIST];
    }
  }

  // Printing the distances with corresponding frequencies
  long int sum = 0;
  for (size_t ix = 0; ix < MAX_DIST; ix++) {
      printf("%d%d.%d%d %d\n",ix/1000,((ix/100)*100-1000*(ix/1000))/100,
      (ix-(ix/100)*100)/10,(ix-(ix/10)*10),numb_distances_times[ix]);
      sum += numb_distances_times[ix];
  }
  free(numb_distances_times);


  return 0;
}
