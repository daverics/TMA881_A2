#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <pthread.h>
#include <unistd.h>
#include <complex.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>


#define PI 3.14159265358979323846
#define NANO 0.000000001

// Define a struct for storing start points and what they converge to
typedef struct {
  double complex number;
  int root;
  int num_of_ite;
} cplx;

// Define a function that concatenates strings in an array

char *concatDiffString(int argc, char *argv[]) {
     int length = 0;
     for (int i = 0; i < argc; ++i)
         length += strlen(argv[i]);


     char *output = (char*) malloc(length + 1);


     char *dest = output;
     for (int i = 0; i < argc; ++i) {
         char *src = argv[i];
         while (*src)
             *dest++ = *src++;
     }
     *dest = '\0';
     return output;
}



// Declare global variables that need to be accessed by all threads

long int numb_degree;
long int numb_pixel;
long int numb_threads;
double complex * roots; // Contains the roots we look for
cplx ** start_space; // Corresponds to int ** results;

// Hardcoded function for complex powers
double complex somePow(double complex a, int d) {
     double complex out = a;
     if (d == 2) {
          out = a*a;
     } else if (d == 3) {
          out = a*a*a;
     } else if (d == 4) {
          double complex b = a*a;
          out = b*b;
     } else if (d == 5) {
          double complex b = a*a;
          out = b*b*a;
     } else if (d == 6) {
          double complex b = a*a*a;
          out = b*b;
     } else if (d == 7) {
          double complex b = a*a;
          double complex c = b*b;
          out = a*b*c;
     } else if (d == 8) {
          double complex b = a*a;
          double complex c = b*b;
          out = c*c;
     } else if (d == 0) {
          out = 1 + 0.0*I;
     }
     return out;
}
//########################################################//

// Function that writes the picture
void * ppm_writer(void * arg){
     // Create two arrays of colour codes to write to file,
     //one for the root and one for number of iterations


  char ** colours = (char**) malloc(sizeof(char*)*10);

  colours[0] = "5 1 1 ";
  colours[1] = "1 5 1 ";
  colours[2] = "1 1 5 ";
  colours[3] = "1 10 5 ";
  colours[4] = "10 5 1 ";
  colours[5] = "1 5 5 ";
  colours[6] = "5 1 5 ";
  colours[7] = "5 5 1 ";
  colours[8] = "5 5 5 ";
  colours[9] = "9 5 1 ";

  char ** colourIter = (char**) malloc(sizeof(char*)*20);


  colourIter[0] = "1 1 1  ";
  colourIter[1]= "5 5 5  ";
  colourIter[2] = "10 10 10  ";
  colourIter[3] = "15 15 15  ";
  colourIter[4] = "20 20 20  ";
  colourIter[5] = "25 25 25  ";
  colourIter[6] = "30 30 30  ";
  colourIter[7] = "35 35 35  ";
  colourIter[8] = "40 40 40  ";
  colourIter[9] = "45 45 45  ";
  colourIter[10] = "50 50 50  ";
  colourIter[11] = "55 55 55  ";
  colourIter[12] = "60 60 60  ";
  colourIter[13] = "63 63 63  ";
  colourIter[14] = "66 66 66  ";
  colourIter[15] = "69 69 69  ";
  colourIter[16] = "72 72 72  ";
  colourIter[17] = "75 75 75  ";
  colourIter[18] = "81 81 81  ";
  colourIter[19] = "84 84 84  ";

  // Create strings containing the correct ppm format
  //to write at top of ppm file

  char n_pix[5];
  sprintf(n_pix, "%d ", numb_pixel);

  char **writeString = malloc(sizeof(char*)*4);

  writeString[0] = "P3\n";
  writeString[1] = n_pix;
  writeString[2] = n_pix;
  writeString[3] = "\n10\n";

  char * stringent = concatDiffString(4,writeString);

  char **writeStringConv = malloc(sizeof(char*)*4);

  writeStringConv[0] = "P3\n";
  writeStringConv[1] = n_pix;
  writeStringConv[2] = n_pix;
  writeStringConv[3] = "\n100\n";

  char * stringentConv = concatDiffString(4,writeStringConv);

  // Make the degree of polynomial a string, to create file names


  char * h = malloc(sizeof(char*));
  sprintf(h, "%d", numb_degree);


  char ** strFile = malloc(sizeof(char*)*3);
  strFile[0] = "newton_attractors_x";
  strFile[1] = h;
  strFile[2] = ".ppm";

  // Create file pointers, and open them for writing
  FILE * fp1;
  FILE * fp2;
  char * fileName = concatDiffString(3,strFile);
  fp1 = fopen(fileName,"w");
  strFile[0] = "newton_convergence_x";
  fileName = concatDiffString(3,strFile);
  fp2 = fopen(fileName,"w");

  // Write the format specifier for ppm file

  fwrite(stringent,sizeof(char),strlen(stringent),fp1);
  fwrite(stringentConv,sizeof(char),strlen(stringentConv),fp2);

  // Number of elements we want to write each time

  size_t numWrite = 10;

  char ** str1 = (char **) malloc(sizeof(char*)*numWrite);
  char ** str2 = (char **) malloc(sizeof(char*)*numWrite);

  //

  bool a = true;
  for (size_t i = 0; i < numb_pixel; i++) {
    for (size_t j = 0; j < numb_pixel; j +=numWrite) {
      a = true;
      while (a){
           // Check if the 10th element is computed
        if (start_space[i][j+numWrite - 1].root != 0){
          a = false;
        }
        else {
          nanosleep((const struct timespec[]){{0, 500000L}}, NULL);
          //printf("aa\n");
        }
      }
      // Create string array for the computed elements to concatenate
      for (size_t jx = 0; jx < numWrite; jx++) {
        str1[jx] = colours[start_space[i][jx+j].root];
        str2[jx] = colourIter[start_space[i][jx+j].num_of_ite];
      }

      // concatenate the string above

      char * out1 = concatDiffString(numWrite,str1);

      char * out2 = concatDiffString(numWrite,str2);

      // Write the concatenated string to respective file

      fwrite(out1,sizeof(char),strlen(out1),fp1);
      fwrite(out2,sizeof(char),strlen(out2),fp2);
    }
  }
  fclose(fp1);
  fclose(fp2);
  pthread_exit(0);
}

//########################################################//
// Calculates one iteration of Newton


double complex newtonUpdate(double complex a, int d) {
    double complex c = somePow(a, d-1);

    double norm = 1/(d*(creal(c)*creal(c) + cimag(c)*cimag(c)));
    double complex b = a - (c*a - 1)*conj(c)*norm;
    return b;
}

//########################################################//

// Iterates newton until convergence or too "large/small"

cplx newton_raphson_method(cplx start_point, int degree,
     double complex * roots, int num_ite) {
          double complex x_k = start_point.number; // Set initial point
          double abs_fx_k = 1.0;
          size_t j = 0;
          // function value is not close enough to zero, and real/imag part < 10^10
          while (abs_fx_k > 0.001 && cabs(x_k) > 0.001 &&
          abs(creal(x_k)) < 10000000000 && abs(cimag(x_k)) < 10000000000 ) {
               x_k = newtonUpdate(x_k, degree);
               abs_fx_k = cabs(somePow(x_k, degree) - 1);
               j++;
          }

          if (abs_fx_k < 0.001) {
               for (size_t k = 0; k < degree; k++) {
                    if (cabs(x_k - roots[k]) < 0.001) {
                         start_point.root = k+1;
                         if (j < 12) {
                              start_point.num_of_ite = 1;
                         } else if (j < 32) {
                              start_point.num_of_ite = j/2 - 1;
                         } else {
                              start_point.num_of_ite = 19;
                         }
                         return start_point;
                    }
               }
          } else {
               start_point.root = degree + 2;
               start_point.num_of_ite = 8;
               return start_point;
          }
}

//########################################################//
//

void * newton_f(void * arg){
  int * block_n = (int*) arg;
  for (size_t ix = *(block_n); ix < numb_pixel; ix+=numb_threads) {
    for (size_t jx = 0; jx < numb_pixel; jx++) {
    start_space[ix][jx]= newton_raphson_method(start_space[ix][jx],numb_degree,roots,50000);
    }
  }
  pthread_exit(0);
}

//########################################################//
// Function that generates the grid of starting points

void generateStartspace(){
  cplx * asentries = (cplx*) malloc(sizeof(cplx) * numb_pixel*numb_pixel);
  start_space = (cplx**) malloc(sizeof(cplx*) * numb_pixel);
  for ( size_t ix = 0, jx = 0; ix < numb_pixel; ++ix, jx+=numb_pixel ){
    start_space[ix] = asentries + jx;
  }
for ( int ix = 0; ix < numb_pixel; ++ix ){
  for ( int jx = 0; jx < numb_pixel; ++jx ){
       start_space[ix][jx].number = -2 + (double) (4*jx)/(numb_pixel-1) + ( - ((double) (4*ix)/(numb_pixel-1)) + 2)*I;
       start_space[ix][jx].root = 0;
  }
}
}

//########################################################//
// Function that precomputes the roots

void generateRoots(int degree){
  roots = (double complex*) malloc(sizeof(double complex)*degree);
  for (int ix = 0; ix < degree; ix++) {
       roots[ix] = cos(ix*2*PI/(degree)) +  sin(ix*2*PI/(degree))*I;
  }
}



int main(int argc,char * argv[]){
  typedef struct timespec TS;
  TS tstart, tend;

  timespec_get(&tstart, TIME_UTC);

  //########################################################//


  if (argc < 4 || argc > 4) {
    printf("Wrong number of arguments\n");
    return 0;
  }

// Extract arguments and store in variables  //


  for (size_t ix = 1; ix < argc-1; ix++) {
    if (argv[ix][0] == '-') {
      if (argv[ix][1] == 't') {
        numb_threads = strtol((argv[ix]+2),NULL,10);
      }
      else if (argv[ix][1] == 'l') {
        numb_pixel = strtol((argv[ix]+2),NULL,10);
      }
    }
  }

  numb_degree = strtol(argv[3],NULL,10);

  //########################################################//


  generateStartspace();
  generateRoots(numb_degree);
  int* block = (int*) malloc(sizeof(int*)*(numb_threads));
  for (size_t ix = 0; ix < numb_threads; ix++) {
    block[ix] = ix;
  }

  //########################################################//

  pthread_t threads[numb_threads];
  pthread_t painter;
  for (size_t ix = 0; ix < numb_threads; ix++) {
    pthread_create(&threads[ix], NULL, newton_f, &block[ix]);
  }

  pthread_create(&painter, NULL, ppm_writer, NULL);


  // Here we join the threads


  for (size_t ix = 0; ix < numb_threads; ix++) {
    pthread_join(threads[ix],NULL);
  }

  pthread_join(painter,NULL);

  timespec_get(&tend, TIME_UTC);
  double recTime = tend.tv_sec - tstart.tv_sec + NANO*(tend.tv_nsec - tstart.tv_nsec);
  printf("Time: %f \n", recTime);

  return 0;
}
