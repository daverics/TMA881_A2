# Assignment report on Threads (hpcgp052)

This report aim to account for our solution and implementation of the assigment Threads. Initially, the enviroment regarding libraries and structures are explained. Then a simplified scheme of the implementation is laid out. Lastly, the performance is discussed and potential improvements to the implementation are suggested.

-------------------------------------------------------------

pthread.h
To use POSIX threads we use the pthread.h library and from here we use the functions pthread_create, pthread_join and pthread_exit. These functions are very easy in their usefulness, the create function simply starts a thread while the master thread keeps going through the main function. The join function waits for the specific thread to finish by executing its respective exit function.

complex.h
We use the complex.h library to incorporate complex numbers and mainly their complex multiplier.

time.h
This library is used primarily for us to benchmark our own program but also use nanosleep in thread that is writing the files. To benchmark we use the function timespec_get.

stdbool.h
The only use for this library is for our while loop in our writer thread, this could probably be avoided, but it looks a bit more clean using booleans.

We define a struct called cplx which contains a complex number from complex.h, an int root and int num_of_ite. The complex number simply corresponds to the coordinate which we are starting our newton iteration from. The root will be set to 0 in the initializing of the space and will be put to a number of the respective root this starting value converge to by the newton-iterations. Lastly, the int num_of_ite corresponds to the number of iterations before it converges close enough to a root, origin or diverges.

The program initializes by taking in the 3 arguments to the master thread, -tXX -lYYY Z, where XX is the number of threads for computations, YYY is the number of pixels for each row and each column, thus creating a YYYxYYY ppm picture. Finally the last argument, Z, is the degree of the polynomial. At the very beginning, the program verifies that the number of arguments is correct and then proceeds to convert these arguments to appropriate numbers, stored as global variables.

Next step of the master thread is to generate the coordinate system divided into points that corresponds to one pixel each, this is done by our function generateStartspace. After this the roots for the polynomial will be calculated by our function generateRoots. The output of these functions were stored as global variables.

Now we want to initialize our threads, using pthread_create with the input of the function newton_f, letting each thread get an argument that contains the row number it should start its calculation on. For example the first row would start calculating on row number 0 and calculate every pixel on that row before jumping down to row number numb_thread. So for example if we initialized four threads, this first thread would start calculating row 4 after it is finished with row 0.

The next step of the master thread after starting the computational threads we will initialize the thread painter that is writing to the two files newton_attractors_xd.ppm and newton_convergence_xd.ppm. After using the function pthread_join to wait for the threads to finish we finish the master thread as well.

-------------------------------------------------------------

The painter thread initializes with the function ppm_writer that receive no input arguments. First of the function/thread declare the “colours” strings and also the “colourIter”. These two string arrays contains the different colours for the roots and different amount of iterations. Immediately the initial strings will be written to the two files with the details declaring the size of ppm file and its format.

Next we will simply loop through the start space, that is all the pixels, row by row and checking if the given pixel has finished calculating. If it has it will now write the appropriate colour and iteration colour to the respective file, and it will write numWrite pixels at a time as well, we have put numWrite = 10. If the calculation for the given pixel isn’t finished we will use nanosleep to wait a bit before we check it again. To write 10 or more pixels at a time we have created a function called ConcatDiffString that simply is concating the strings, thus we call fwrite less times. When every pixel have finished we are finished with this thread and will call pthread_exit simply.

As mentioned formerly, each computational thread is called with a designated block of starting points. For each starting point in the block, a Newton-Raphson search is initalized iteratively by the function newton_raphson_method. In this function the next point of the Newton-Raphson search is computed itertively until one of the termination criterions is satisfied. The next point is computed from the current point using the function NewtonUpdate. NewtonUpdate utilizes the function somePow, which is an alternative version of the function pow, designed to minimize the amount of times we call the complex multiplier supplied by the library complex.h.

The termination criteria for convergence is met if the value of the functions is below 10^-3, which is sufficient in order be within a radius of 0.001 from one of the roots. On the other hand, if the current point is within a radius of 10^-3 from the origin the starting point is said to diverge and thus the search is terminated. The search is also terminated if either the real or imaginary part of the current point is greater than 10^10. If the search is terminated due to convergence, the starting point is assigned the index of the associated root to which it converged as well as the number of iterations it took. On the other hand, if it terminates due to divergence, the corresponding index root and number of iterations are set to specific values.

-------------------------------------------------------------

Running the program several times for some fixed input arguments seems to result in varying runtimes, sometimes beating the performance goal by a factor of up to 10, while at other times being way slower. The following aspects most likely play a big role in that the program can meet the performance goals:
- the function computing powers of complex numbers is hardcoded to optimize for the specific degrees in the performance goals,
- the calculations within each iteration of the Newton method is simplified to avoid unneccessary computations of square roots and powers,
- Instead of calculating the distance to all roots in each iteration, the absolute value of the function value is calculated.

Given this it seems most likely this variance in performance can be due to extensive use of memory. Since each cplx struct is of size 16 + 4 + 4 = 24 bytes, if 1000 is passed as the argument for number of pixels, then our space of points requires almost 24MB of memory. If one wanted a picture of even higher resolution, this approach is not really feasible. How could one make the memory usage more efficient? One could in theory keep the layout of the program, but instead of allocating memory for all pixels just do it for one row. Then one computes the Newton iterations, writes the colours for the first row, and then write over this memory with the pixels of the second line and so on. This would drastically reduce memory usage.

Another mathematical fact that could be harnessed for faster runtimes is the following: The roots of the polynomial x^d - 1 are the d roots of unity, and these roots are closed under conjugation, i.e. the conjugate of a root of x^d - 1 is another root of x^d - 1. If one takes the conjugate of each term in a converging sequence, then this will correspond to using the conjugate of x_{k} as the start point, and the root the sequence converges to is the conjugate of the original root. Hence, it suffices to compute the convergence for the upper half of the square, since the lower half can be found by conjugation of starting points and corresponding roots.
